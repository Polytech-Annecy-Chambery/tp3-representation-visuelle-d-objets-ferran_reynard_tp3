# -*- coding: utf-8 -*-
"""
Created on Tue Dec  7 14:11:15 2021

@author: reynarle
"""

import pygame


pygame.init()
ecran = pygame.display.set_mode((300, 200))

continuer = True
while continuer:
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            continuer = False

pygame.quit()